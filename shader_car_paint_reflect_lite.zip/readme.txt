Resource: Shader Car Paint reflect LITE v 0.2.5
Author: Ren_712
Contact: knoblauch700@o2.pl
Update 0.2.4
-Changed the reflection method


This is an alternate car paint reflect shader.

Unlike the prevoius release, shader effect is drawn as a second layer.
This way we can just add the reflection to the gtasa graphics effect.
The reflection is based on screen source, giving an illusion 
of realtime reflection. Effect is similar to what is seen in ENB.  
It is applied to vehicle paint and windshields.
The effect uses max distance variable to optimise drawing.
It requires (just as the carpaint shader) PS Model 2.0 GFX.
So it will run on almost anything.

have fun
Ren712

knoblauch700@o2.pl
