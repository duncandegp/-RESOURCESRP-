function onClientElementDataChange(dataName, oldValue)
	if(dataName == "Vehicle Reflections") then
		local enabled = getElementData(localPlayer, dataName) or false
		if enabled then
			startCarPaintReflectLite()
		else
			stopCarPaintReflectLite()
		end
	end
end
addEventHandler("onClientElementDataChange", localPlayer, onClientElementDataChange)