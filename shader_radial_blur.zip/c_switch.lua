function onClientElementDataChange(dataName, oldValue)
	if(dataName == "Radial Blur") then
		local enabled = getElementData(localPlayer, dataName) or false
		if enabled then
			enableRadialBlur()
		else
			disableRadialBlur()
		end
	end
end
addEventHandler("onClientElementDataChange", localPlayer, onClientElementDataChange)