function onClientElementDataChange(dataName, oldValue)
	if(dataName == "Bloom") then
		local enabled = getElementData(localPlayer, dataName) or false
		if enabled then
			enableBloom()
		else
			disableBloom()
		end
	end
end
addEventHandler("onClientElementDataChange", localPlayer, onClientElementDataChange)