Instruction:

1. Press 'k' to get the ball.
2. Move mouse to rotate player.
3. Controls:

OFFENSIVE MOVES: 
'w' - run
'shift' - walk
'left mouse button' - jump shot
'right mouse button' - dunk

DEFENSIVE MOVES:
'w' - run
'a' - step left
'd' - step right

4. How to stop play?

- Just press 'k' again.

5. Where can I get the ball?

- Use /createball command, and the ball will appear on the ground.
If you want to create more balls just /createball command again.

6. There are any courts to play in basketball?

- Just use /court command that will automatically warp you to the court.

7. I can use it on my server?

- Yes, you can freely use it on your server.

8. It is possible to make soccer?

- Yes, but you need new anims like kick etc.

9. Why I never miss?

- It's unstable version only for test first poor object dynamic,
something like "luck" I'll make in next version.

In next (stable) version:

