local info = guiCreateLabel(0.5,0.5,1,1,"Presiona K para jugar Baloncesto.",true)
guiSetVisible(info,false)

function test()
local pX,pY,pZ = getElementPosition(localPlayer)
local gX,gY,gZ = getGroundPosition(pX,pY,pZ)
ball = createObject(2114,pX,pY,pZ-0.9)
end
addCommandHandler("createball",test)

function court()
court = createObject(8417,2877.3999023438,2170.3999023438,9.899995803833,0,0,270) -- court
lax2 = createObject(946, 2880.6000976563, 2186.1000976563, 12.10000038147,0,0,180) -- lax -- from right side
--lax = createObject(946, 2871.6000976563, 2186, 12.10000038147,0,0,180) -- lax
end
addEventHandler("onClientResourceStart",root,court)

function warpToCourt()
setElementPosition(localPlayer,2880.6000976563, 2170.1000976563, 12.10000038147)
end
addCommandHandler("court",warpToCourt)

local inicjacja = 0
local picked = 0
local handled = 0
local offense = 0
local defense = 0
local luck = 70 -- max 100 // I will use it in next version

addEventHandler("onClientRender",root,
function(localPlayer)
if ball then
        if getElementModel(ball) == 2114 then
        local bX,bY,bZ = getElementPosition(ball)
        local mX,mY,mZ = getCameraMatrix()
        local distance = getDistanceBetweenPoints3D(mX,mY,mZ,bX,bY,bZ)
		attached = getElementAttachedTo(ball)
		attachedElements = getAttachedElements ( ball )
            if distance <= 7 and picked == 0 then
                guiSetVisible(info,true)
				if inicjacja == 0 then
                inicjacja = 1
                bindKey("k","down",play)
                end
            elseif distance > 7 and picked == 0 then
                guiSetVisible(info,false)
				if inicjacja == 1 then
                inicjacja = 0
                unbindKey("k","down",play)
                end
            end
        end
    end
end
)

addEventHandler("onClientResourceStop",root,
function()
    toggleAllControls(true)
    unbindKey("w","down",controls)
	unbindKey("w","up",controls)
	unbindKey("s","down",controls)
	unbindKey("s","up",controls)
	unbindKey("a","down",controls)
	unbindKey("a","up",controls)
	unbindKey("d","down",controls)
	unbindKey("d","up",controls)
	unbindKey("mouse1","down",controls)
	unbindKey("mouse2","down",controls)
	unbindKey("lshift","down",controls)
	setPedAnimation(localPlayer,false)
end
)


function play()
if ball then
if getElementModel(ball) == 2114 then
    if picked == 0 then
    picked = 1
	setPedAnimation(localPlayer,"bsktball","BBALL_pickup",true,false)
	toggleAllControls(false)
	bindKey("w","down",controls)
	bindKey("w","up",controls)
	bindKey("s","down",controls)
	bindKey("s","up",controls)
	bindKey("a","down",controls)
	bindKey("a","up",controls)
	bindKey("d","down",controls)
	bindKey("d","up",controls)
	bindKey("mouse1","down",controls)
	bindKey("mouse2","down",controls)
	bindKey("lshift","down",controls)
	bindKey("lshift","up",controls)
	guiSetVisible(info,false)
	    if handled == 0 then
	    handled = 1
	    addEventHandler("onClientPreRender",root,rotationN)
	    end
    elseif picked == 1 then
    picked = 0
	local bX,bY,bZ = getElementPosition(localPlayer)
	toggleAllControls(true)
    unbindKey("w","down",controls)
	unbindKey("w","up",controls)
	unbindKey("s","down",controls)
	unbindKey("s","up",controls)
	unbindKey("a","down",controls)
	unbindKey("a","up",controls)
	unbindKey("d","down",controls)
	unbindKey("d","up",controls)
	unbindKey("mouse1","down",controls)
	unbindKey("mouse2","down",controls)
	unbindKey("lshift","down",controls)
	unbindKey("lshift","up",controls)
	setPedAnimation(localPlayer,false)
	setElementPosition(ball,bX,bY,bZ-1)
	removeEventHandler("onClientPreRender",root,rotationN)
	handled = 0
	end
end
end
end

function findRotation(x1,y1,x2,y2)
 
  local t = -math.deg(math.atan2(x2-x1,y2-y1))
  if t < 0 then t = t + 360 end;
  return t;
 
end

function controls(key,state)
	if picked == 1 then
	    offense = 1
		defense = 0
			if offense == 1 then
			if key == "w" and state == "down" then
			setPedAnimation(localPlayer,"bsktball","BBALL_run",true,true,true)
			loop = setTimer( dynamic_loop,50,0 )
			
			
			elseif key == "w" and state == "up" then
			setPedAnimation(localPlayer,"bsktball","BBALL_idleloop",true,true)
			
			elseif key == "lshift" and state == "down" then
			setPedAnimation(localPlayer,"bsktball","BBALL_walk",true,true,true)
			setTimer( dynamic_loop,50,0 )
			
			elseif key == "lshift" and state == "up" then
			setPedAnimation(localPlayer,"bsktball","BBALL_idleloop",true,true)
			
			elseif key == "mouse1" and state == "down" then
			setPedAnimation(localPlayer,"bsktball","BBALL_Jump_Shot",true,false)
			local lx,ly,lz = getElementPosition(lax2)
	        local x,y,z = getElementPosition(localPlayer)
			--in next version
	        --setPedRotation(localPlayer, findRotation(x,y,lx,ly)+180 );
			killTimer( loop )
			shoot = setTimer( dynamic_shoot,50,1 )
			picked = 0
			
			elseif key == "mouse2" and state == "down" then
			setPedAnimation(localPlayer,"bsktball","BBALL_Dnk_Gli",true,false)
			killTimer( loop )
			shoot = setTimer( dynamic_shoot,50,1 )
			picked = 0
			end
		end
	elseif picked == 0 then
	    offense = 0
		defense = 1
			if defense == 1 then
			if key == "a" and state == "down" then
			setPedAnimation(localPlayer,"bsktball","BBALL_def_stepL",true,true)
			
			elseif key == "a" and state == "up" then
			setPedAnimation(localPlayer,"muscular","MuscleIdle",true,true)
			
			elseif key == "d" and state == "down" then
			setPedAnimation(localPlayer,"bsktball","BBALL_def_stepR",true,true)
			
			elseif key == "d" and state == "up" then
			setPedAnimation(localPlayer,"muscular","MuscleIdle",true,true)
			
			elseif key == "w" and state == "down" then
			setPedAnimation(localPlayer,"ped","run_player",true,true)
			
			elseif key == "w" and state == "up" then
			setPedAnimation(localPlayer,"muscular","MuscleIdle",true,true)
			end
		end
	end
end


function rotationN()
    local cx,cy,cz, lx, ly, lz = getCameraMatrix()
	local x,y,z = getElementPosition(localPlayer)
	setPedRotation(localPlayer, findRotation(x,y,cx,cy)+180 );
end

function hand()
    hX,hY,hZ = getPedBonePosition(localPlayer,25)
end
addEventHandler("onClientRender",root,hand)


function dynamic_loop()
    if picked == 1 then
	setElementPosition(ball,hX,hY,hZ-0.5)
    end
end

-- first version, I know, very poor - 0 math :), but it works.
function dynamic_shoot() -- passed
	targetX,targetY,targetZ = 2880.6000976563, 2185.5000976563, 13.10000038147
	moveObject(ball,500,targetX,targetY,targetZ)
	setTimer(
	function()
	moveObject(ball,500,targetX,targetY,targetZ-3)
	end
	,600,1)
end


-- something like that I'll make too in next version
-- // I WILL INVOLVE TOO OBJECT DYNAMIC
function dynamic_shoot_fail() -- failed
	targetX2,targetY2,targetZ2 = 2879.6000976563, 2185.5000976563, 13.10000038147
	moveObject(ball,500,targetX2,targetY2,targetZ2)
	setTimer(
	function()
	moveObject(ball,500,targetX2+2,targetY2-3,targetZ2-3)
	end
	,500,1)
end

