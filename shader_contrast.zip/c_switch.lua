function onClientElementDataChange(dataName, oldValue)
	if(dataName == "Contrast") then
		local enabled = getElementData(localPlayer, dataName) or false
		if enabled then
			enableContrast()
		else
			disableContrast()
		end
	end
end
addEventHandler("onClientElementDataChange", localPlayer, onClientElementDataChange)