function onClientElementDataChange(dataName, oldValue)
	if(dataName == "DoF") then
		local enabled = getElementData(localPlayer, dataName) or false
		if enabled then
			enableDoF()
		else
			disableDoF()
		end
	end
end
addEventHandler("onClientElementDataChange", localPlayer, onClientElementDataChange)