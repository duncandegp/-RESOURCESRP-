local window

local styles = {
	{"Normal", 0},
	{"Mujer 1", 129},
	{"Mujer 2", 133},
	{"Sexy", 132},
	{"Gangsta1", 121},
	{"Gangsta2", 122},
	{"Abuelita", 134},
	{"Abuelito", 120},
	{"Abuelo", 123},
	{"Hombre gordo", 124},
	{"Mujer Gorda", 135},
	{"Prostituta", 133},
	{"SWAT agente", 128},
	{"Hombre borracho", 126},
	{"Ciego", 127},
	{"Caminante astuta", 69},
	{"Hombre", 118},
	{"Patinador", 125}
}

function createStylePanel()
	if isElement(window) and guiGetVisible(window) == true then
		return hideStylePanel()
	end
	local sw, sh = guiGetScreenSize()
	window = guiCreateWindow(sw / 1.4, sh / 4, sw / 4.5, sh / 2, "Manera de andar", false)
	grid = guiCreateGridList(0, 0.06, 1, 0.75, true, window)
	col1 = guiGridListAddColumn(grid, "Manera de andar", 0.9)
	button1 = guiCreateButton(0, 0.82, 1, 0.07, "Cambiar", true, window)
	addEventHandler("onClientGUIClick", button1, selectStyle, false)
	addEventHandler("onClientGUIDoubleClick", grid, selectStyle, false)
	button2 = guiCreateButton(0, 0.9, 1, 0.07, "Cerrar", true, window)
	addEventHandler("onClientGUIClick", button2, hideStylePanel, false)
	showCursor(true)
	for i, v in ipairs(styles) do
		local row = guiGridListAddRow(grid)
		guiGridListSetItemText(grid, row, col1, v[1], false, false)
		guiGridListSetItemData(grid, row, col1, v[2], false, false)
	end
end
addCommandHandler("andar", createStylePanel)
addCommandHandler("maneradeandar", createStylePanel)
addCommandHandler("sistemadeandar", createStylePanel)
addCommandHandler("caminar", createStylePanel)
addCommandHandler("cambiarcaminar", createStylePanel)
addCommandHandler("sistemadecaminar", createStylePanel)
addCommandHandler("caminata", createStylePanel)

function hideStylePanel()
	removeEventHandler("onClientGUIClick", button1, selectStyle, false)
	removeEventHandler("onClientGUIDoubleClick", grid, selectStyle, false)
	removeEventHandler("onClientGUIClick", button2, hideStylePanel, false)
	destroyElement(window)
	showCursor(false)
end

function selectStyle()
	local item = guiGridListGetSelectedItem(grid)
	if item == -1 then
		return
	end
	local theStyle = guiGridListGetItemData(grid, item, 1)
	local theStyle_text = guiGridListGetItemText(grid, item, 1)
	outputChatBox("You changed walking style! New walking style: " .. theStyle_text)
	triggerServerEvent("onApplyStyle", resourceRoot, theStyle)
	hideStylePanel()
end

--[[function setStyleCmd(localPlayer, commandName, theStyleNo)
		local style = tonumber(theStyleNo)
		outputChatBox("You changed walking style! New walking style: "..theStyleNo)
		triggerServerEvent("onApplyStyleCmd", resourceRoot, style)
end
addCommandHandler("setwalkingstyle",setStyleCmd)]] --