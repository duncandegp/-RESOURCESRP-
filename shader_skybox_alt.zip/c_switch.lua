function onClientElementDataChange(dataName, oldValue)
	if(dataName == "Skybox") then
		local enabled = getElementData(localPlayer, dataName) or false
		if enabled then
			startShaderResource()
		else
			stopShaderResource()
		end
	end
end
addEventHandler("onClientElementDataChange", localPlayer, onClientElementDataChange)