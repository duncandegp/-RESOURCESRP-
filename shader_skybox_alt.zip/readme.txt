resource: Shader_Skybox_alt v0.53
author: Ren712 
contact: knoblauch700@o2.pl

Description:
I've seen a cool and simple skybox mod for GTASA
http://playmods.blogspot.com/2012/12/skybox.html
I wanted to convert it and ended up with this.

So the skydome texture I have taken from this mod.
Everything else is made from scratch.

Basically it's a static skydome/skybox. Instead of a big
cubemap file you can add a single compressed jpg texture.

Download custom texture pack 1 - 10 fisheye images: set gAngularTex = false
https://www.dropbox.com/s/d1azqopdxk0oejk/clouds_pack.zip?dl=0
Download custom texture pack 2 - 14 Equirectangular images:set gAngularTex = true
https://www.dropbox.com/s/myb3mwd58oeql8r/clouds_pack2.zip?dl=0

